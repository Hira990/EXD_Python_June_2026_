from fastapi import FastAPI, status
import requests, datetime, json
from bs4 import BeautifulSoup
from fastapi.responses import JSONResponse

from test import page_number

app = FastAPI()


@app.get("/get-hello-message")
async def get_hello_message():
    jobs = []
    page_number = 1
    while True:
        url = f"https://www.python.org/jobs?page={page_number}"
        response = requests.get(url)
        print(response.status_code)
        if response.status_code != 200:
            print("Error, quiting...")
            break
        # print(response.text)
        html_response = response.text

        soup = BeautifulSoup(html_response, 'html.parser')
        # print(soup.prettify())

        li_items = soup.select("ol.list-recent-jobs.list-row-container.menu > li")

        for item in li_items:
            company_span = item.find("span", class_="listing-company-name")
            job_title = company_span.find("a").get_text(strip=True)
            company_name = list(company_span.stripped_strings)[-1]
            print(job_title)
            print(company_name)

            job_type_span = item.find("span", class_="listing-job-type")
            job_type_a_tags = job_type_span.find_all("a")
            job_tags = []
            for a_tag in job_type_a_tags:
                job_tags.append(a_tag.get_text(strip=True))
            print(job_tags)

            date_posted_span = item.find("span", class_="listing-posted")
            date_posted = date_posted_span.find("time").get_text(strip=True)

            category_span = item.find("span", class_="listing-company-category")
            category = category_span.find("a").get_text(strip=True)

            location_span = item.find("span", class_="listing-location")
            location = location_span.find("a").get_text(strip=True)

            print("--------------")
            job_object = {
                "title": job_title,
                "company": company_name,
                "tags": job_tags,
                "date_posted": date_posted,
                "category": category,
                "location": location
            }
            jobs.append(job_object)

        page_number += 1

    return {
        "message": "jobs extracted!",
        "jobs": jobs
    }

@app.get("/get-jobs-by-category")
async def get_jobs_by_category(category: str):
    print("category:", category)
    if category == "Developer Engineer":
        category = "developer-engineer"
    jobs = []

    # url = "https://www.python.org/jobs/category/developer-engineer/"
    url = f"https://www.python.org/jobs/category/{category}/"
    response = requests.get(url)
    print()
    if response.status_code != 200:
        return JSONResponse(
            status_code=response.status_code,
            content={
                "message": "category not found!",
            }
        )

    # print(response.text)
    html_response = response.text

    soup = BeautifulSoup(html_response, 'html.parser')
    # print(soup.prettify())

    li_items = soup.select("ol.list-recent-jobs.list-row-container.menu > li")

    for item in li_items:
        company_span = item.find("span", class_="listing-company-name")
        job_title = company_span.find("a").get_text(strip=True)
        company_name = list(company_span.stripped_strings)[-1]
        print(job_title)
        print(company_name)

        job_type_span = item.find("span", class_="listing-job-type")
        job_type_a_tags = job_type_span.find_all("a")
        job_tags = []
        for a_tag in job_type_a_tags:
            job_tags.append(a_tag.get_text(strip=True))
        print(job_tags)

        date_posted_span = item.find("span", class_="listing-posted")
        date_posted = date_posted_span.find("time").get_text(strip=True)

        category_span = item.find("span", class_="listing-company-category")
        category = category_span.find("a").get_text(strip=True)

        location_span = item.find("span", class_="listing-location")
        location = location_span.find("a").get_text(strip=True)

        print("--------------")
        job_object = {
            "title": job_title,
            "company": company_name,
            "tags": job_tags,
            "date_posted": date_posted,
            "category": category,
            "location": location
        }
        jobs.append(job_object)

    return {
        "message": "jobs extracted!",
        "jobs": jobs
    }


@app.get("/check-patient")
async def check_patient(patient_name: str):
    try:
        print(f"Check Patient: {patient_name}")

        # Read patients from a file
        try:
            with open("patient.json", "r") as f:
                patients = json.load(f)
        except FileNotFoundError:
            print("patient.json not found")
            return JSONResponse(
                status_code=404,
                content={
                    "message": "patient file not found!",
                    "is_found": False,
                }
            )

        names_list = [p["name"] for p in patients]
        if patient_name in names_list:
            return JSONResponse(
                status_code=200,
                content={
                    "is_found": True,
                }
            )
        else:
            return JSONResponse(
                status_code=404,
                content={
                    "is_found": False,
                }
            )
    except Exception as e:
        return JSONResponse(
            status_code=500,
            content={
                "message": str(e),
            }
        )
